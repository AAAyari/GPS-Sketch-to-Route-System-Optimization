from gps_algorithms import *
from geopy.distance import geodesic
from collections import OrderedDict

SNAP_RADIUS_KM = 25
SPACING_THRESHOLD_KM = 25

ALGORITHM_FUNCTIONS = {
    'dijkstra': dijkstra,
    'bellman_ford': bellman_ford,
    'dfs': dfs,
    'bfs': bfs
}

def get_nearest_city(point):
    min_city = None
    min_dist = float('inf')
    for city, coord in coordinates.items():
        dist = geodesic((point['lat'], point['lng']), coord).km
        if dist < min_dist and dist <= SNAP_RADIUS_KM:
            min_dist = dist
            min_city = city
    return min_city

def deduplicate_city_sequence(city_list):
    seen = set()
    ordered = []
    for city in city_list:
        if city not in seen:
            seen.add(city)
            ordered.append(city)
    return ordered

def score_path(user_path, optimal_path):
    user_set = set(user_path)
    optimal_set = set(optimal_path)
    overlap = len(user_set & optimal_set)
    return round((overlap / len(optimal_set)) * 100) if optimal_set else 0

def process_sketch(sketch_points, algorithm='dijkstra'):
    print("SKETCH DEBUG: got", len(sketch_points), "points")
    snapped_cities = [get_nearest_city(pt) for pt in sketch_points]
    snapped_cities = [c for c in snapped_cities if c is not None]
    print("Snapped cities:", snapped_cities)
    city_sequence = deduplicate_city_sequence(snapped_cities)

    if len(city_sequence) < 2:
        print("Not enough cities for a valid path.")
        return None, 0


    start, *waypoints, end = city_sequence[0], *city_sequence[1:-1], city_sequence[-1]

    best_path = []
    total_distance = 0
    algo = ALGORITHM_FUNCTIONS.get(algorithm, dijkstra)

    for i in range(len(city_sequence) - 1):
        seg_start = city_sequence[i]
        seg_end = city_sequence[i + 1]
        path_segment, dist = algo(graph, seg_start, seg_end)

        if not path_segment:
            return None, 0

        if best_path and path_segment[0] == best_path[-1]:
            path_segment = path_segment[1:]

        best_path.extend(path_segment)
        total_distance += dist

    optimal_path, _ = dijkstra(graph, start, end)
    score = score_path(city_sequence, optimal_path)
    print("Snapped cities:", snapped_cities)
    print("City sequence:", city_sequence)

    seen = set()
    unique_path = []
    for city in best_path:
        if city not in seen and is_city_near_sketch(city, sketch_points):
            seen.add(city)
            unique_path.append(city)

    return unique_path, score


def is_city_near_sketch(city, sketch_points, radius_km=25):
    return any(geodesic(coordinates[city], (pt['lat'], pt['lng'])).km < radius_km for pt in sketch_points)

