import networkx as nx
from flask import Flask, render_template, request, jsonify
import os
from sklearn.cluster import KMeans
import numpy as np
from itertools import permutations
import copy

# Graph of major French cities and distances (simplified for demo)
graph = {
    'Paris': {'Lyon': 465, 'Nantes': 385, 'Lille': 225},
    'Lyon': {'Paris': 465, 'Marseille': 315, 'Nice': 470},
    'Nantes': {'Paris': 385, 'Bordeaux': 335},
    'Lille': {'Paris': 225, 'Strasbourg': 520},
    'Strasbourg': {'Lille': 520, 'Lyon': 490},
    'Bordeaux': {'Nantes': 335, 'Toulouse': 245},
    'Toulouse': {'Bordeaux': 245, 'Marseille': 405},
    'Marseille': {'Lyon': 315, 'Toulouse': 405, 'Nice': 200},
    'Nice': {'Lyon': 470, 'Marseille': 200}
}

coordinates = {
    'Paris': (48.8566, 2.3522),
    'Lyon': (45.7640, 4.8357),
    'Marseille': (43.2965, 5.3698),
    'Nice': (43.7102, 7.2620),
    'Nantes': (47.2184, -1.5536),
    'Bordeaux': (44.8378, -0.5792),
    'Toulouse': (43.6047, 1.4442),
    'Lille': (50.6292, 3.0573),
    'Strasbourg': (48.5734, 7.7521)
}

def dijkstra(graph, start, end):
    import heapq
    queue = [(0, start)]
    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    previous = {node: None for node in graph}

    while queue:
        current_distance, current_node = heapq.heappop(queue)

        if current_node == end:
            break

        for neighbor, weight in graph[current_node].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous[neighbor] = current_node
                heapq.heappush(queue, (distance, neighbor))

    path = []
    node = end
    while node:
        path.insert(0, node)
        node = previous[node]
    return path if distances[end] != float('inf') else [], distances[end]

def bellman_ford(graph, start, end):
    distances = {node: float('inf') for node in graph}
    previous = {node: None for node in graph}
    distances[start] = 0

    edges = [(u, v, w) for u in graph for v, w in graph[u].items()]

    for _ in range(len(graph) - 1):
        for u, v, w in edges:
            if distances[u] + w < distances[v]:
                distances[v] = distances[u] + w
                previous[v] = u

    path = []
    node = end
    while node:
        path.insert(0, node)
        node = previous[node]
    return path if distances[end] != float('inf') else [], distances[end]

def dfs(graph, start, end, visited=None, path=None):
    if visited is None:
        visited = set()
    if path is None:
        path = []
    visited.add(start)
    path.append(start)
    if start == end:
        return path, 0
    for neighbor in graph[start]:
        if neighbor not in visited:
            result, _ = dfs(graph, neighbor, end, visited, path)
            if result and result[-1] == end:
                return result, calculate_path_distance(result)
    path.pop()
    return [], 0

def bfs(graph, start, end):
    from collections import deque
    queue = deque([[start]])
    visited = set()

    while queue:
        path = queue.popleft()
        node = path[-1]
        if node == end:
            return path, calculate_path_distance(path)
        if node not in visited:
            visited.add(node)
            for neighbor in graph[node]:
                queue.append(path + [neighbor])
    return [], 0

def calculate_path_distance(path):
    distance = 0
    for i in range(len(path) - 1):
        distance += graph[path[i]][path[i + 1]]
    return distance

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cluster')
def cluster():
    return render_template("cluster.html")

@app.route('/api/path', methods=['POST'])
def get_path():
    data = request.json
    start = data['start']
    end = data['end']
    algorithm = data['algorithm']
    waypoints = data.get('waypoints', [])
    traffic = data.get('traffic', {})

    import copy
    adjusted_graph = copy.deepcopy(graph)

    traffic_multipliers = {'low': 1.0, 'medium': 1.3, 'high': 1.6}

    for city, level in traffic.items():
        if city in adjusted_graph:
            multiplier = traffic_multipliers.get(level, 1.0)
            for neighbor in adjusted_graph[city]:
                adjusted_graph[city][neighbor] *= multiplier
            for other in adjusted_graph:
                if city in adjusted_graph[other]:  # Fixed variable name
                    adjusted_graph[other][city] *= multiplier  # Fixed variable name

    algorithms = {
        'dijkstra': dijkstra,
        'bellman_ford': bellman_ford,
        'dfs': dfs,
        'bfs': bfs
    }

    if algorithm not in algorithms:
        return jsonify({'error': 'Invalid algorithm'}), 400

    from itertools import permutations

    best_path = []
    min_total_distance = float('inf')

    for perm in permutations(waypoints):
        candidate_path = [start] + list(perm) + [end]
        total_distance = 0
        full_path = []

        for i in range(len(candidate_path) - 1):
            leg_start = candidate_path[i]
            leg_end = candidate_path[i + 1]
            segment_path, dist = algorithms[algorithm](adjusted_graph, leg_start, leg_end)

            if not segment_path:
                total_distance = float('inf')
                break

            if full_path and segment_path[0] == full_path[-1]:
                segment_path = segment_path[1:]

            full_path.extend(segment_path)
            total_distance += dist

        if total_distance < min_total_distance:
            min_total_distance = total_distance
            best_path = full_path

    path_coords = [
        {'city': city, 'lat': coordinates[city][0], 'lon': coordinates[city][1]}
        for city in best_path
    ]

    return jsonify({'path': path_coords, 'distance': min_total_distance})

def apply_traffic_weights(base_graph, traffic):
    adjusted = copy.deepcopy(base_graph)
    traffic_multipliers = {'low': 1.0, 'medium': 1.3, 'high': 1.6}

    for city, level in traffic.items():
        if city in adjusted:
            multiplier = traffic_multipliers.get(level, 1.0)
            for neighbor in adjusted[city]:
                adjusted[city][neighbor] *= multiplier
            for other in adjusted:
                if city in adjusted[other]:
                    adjusted[other][city] *= multiplier

    return adjusted

@app.route('/api/clustered_routes', methods=['POST'])
def clustered_routes():
    try:
        data = request.get_json()
        print("Request Data:", data)  # Debugging

        start = data.get("start")
        end = data.get("end")
        algorithm = data.get("algorithm")
        waypoints = data.get("waypoints", [])
        traffic = data.get("traffic", {})
        user_specified = data.get("num_deliverymen")

        if not start or not waypoints:
            return jsonify({'error': 'Missing required fields'}), 400

        adjusted_graph = apply_traffic_weights(graph, traffic)

        # Prepare coordinates for clustering
        coord_list = [coordinates[city] for city in waypoints]
        X = np.array(coord_list)

        # Determine the number of clusters
        if user_specified:
            num_clusters = int(user_specified)
        else:
            num_clusters = min(2, len(waypoints))  # Default to 2 clusters if not specified

        num_clusters = min(num_clusters, len(waypoints))
        print(f"Number of clusters: {num_clusters}")  # Debugging

        kmeans = KMeans(n_clusters=num_clusters, random_state=0).fit(X)
        labels = kmeans.labels_

        # Group waypoints by cluster
        clusters = {}
        for i, label in enumerate(labels):
            clusters.setdefault(label, []).append(waypoints[i])

        print(f"Clusters: {clusters}")  # Debugging

        algorithms = {
            'dijkstra': dijkstra,
            'bellman_ford': bellman_ford,
            'dfs': dfs,
            'bfs': bfs
        }

        selected_algo = algorithms.get(algorithm)
        if not selected_algo:
            return jsonify({'error': 'Invalid algorithm'}), 400

        routes = []

        for cluster_id, cities in clusters.items():
            best_path = []
            min_distance = float('inf')

            possible_end = [end] if end and end != "none" else cities

            for e in possible_end:
                for perm in permutations(cities):
                    candidate_path = [start] + list(perm) + [e]
                    total_dist = 0
                    full_path = []

                    for i in range(len(candidate_path) - 1):
                        segment, dist = selected_algo(adjusted_graph, candidate_path[i], candidate_path[i + 1])
                        if not segment:
                            total_dist = float('inf')
                            break
                        if full_path and segment[0] == full_path[-1]:
                            segment = segment[1:]
                        full_path.extend(segment)
                        total_dist += dist

                    if total_dist < min_distance:
                        min_distance = total_dist
                        best_path = full_path

            path_coords = [
                {'city': city, 'lat': coordinates[city][0], 'lon': coordinates[city][1]}
                for city in best_path
            ]

            routes.append({
                'cluster': int(cluster_id) + 1,
                'path': path_coords,
                'distance': round(min_distance, 2)
            })

        return jsonify({'routes': routes})
    except Exception as e:
        print("Error in /api/clustered_routes:", str(e))  # Debugging
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/favicon.ico')
def favicon():
    return '', 204  # Suppress favicon.ico error

#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
@app.route('/api/sketch-path', methods=['POST'])
def sketch_path():
    data = request.json
    sketch_points = data.get('sketch', [])
    algorithm = data.get('algorithm', 'dijkstra')

    if not sketch_points:
        return jsonify({'error': 'No sketch data provided'}), 400

    path, score = process_sketch(sketch_points, algorithm)
    if not path:
        return jsonify({'error': 'Could not determine a valid path'}), 400

    return jsonify({
        'path': path,
        'score': score
    })
#AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA


if __name__ == "__main__":
    app.run(debug=True)
