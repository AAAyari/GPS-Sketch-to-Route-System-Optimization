document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('pathForm');
    const optimizeBtn = document.getElementById('optimizeBtn');
    const startSelect = document.getElementById('start');
    const endSelect = document.getElementById('end');
    const citiesContainer = document.getElementById('clusterDeliveryCities');
    const trafficContainer = document.getElementById('cityTrafficControls');

    // Check for missing DOM elements
    if (!form || !optimizeBtn || !startSelect || !endSelect || !citiesContainer || !trafficContainer) {
        console.error("Required DOM elements are missing.");
        return;
    }

    // Add event listener for the Optimize Delivery button
    optimizeBtn.addEventListener('click', (e) => {
        e.preventDefault(); // Prevent default button behavior
        console.log("Optimize Delivery button clicked"); // Debugging
        form.dispatchEvent(new Event('submit')); // Trigger form submission
    });

    // Populate cities
    const cities = {
        'Paris': [48.8566, 2.3522],
        'Lyon': [45.7640, 4.8357],
        'Marseille': [43.2965, 5.3698],
        'Nice': [43.7102, 7.2620],
        'Nantes': [47.2184, -1.5536],
        'Bordeaux': [44.8378, -0.5792],
        'Toulouse': [43.6047, 1.4442],
        'Lille': [50.6292, 3.0573],
        'Strasbourg': [48.5734, 7.7521]
    };

    Object.keys(cities).forEach(city => {
        const option1 = new Option(city, city);
        const option2 = new Option(city, city);
        startSelect.appendChild(option1);
        endSelect.appendChild(option2);

        const div = document.createElement('div');
        div.className = "cluster-checkbox";
        div.innerHTML = `
            <label>
                <input type="checkbox" class="cluster-city" value="${city}"> ${city}
            </label>`;
        citiesContainer.appendChild(div);

        const wrapper = document.createElement('div');
        wrapper.style.flex = "0 0 calc(50% - 10px)";
        wrapper.style.display = "flex";
        wrapper.style.alignItems = "center";
        wrapper.style.gap = "10px";

        const label = document.createElement('label');
        label.textContent = city;
        label.style.width = "80px";
        label.style.fontWeight = "bold";

        const select = document.createElement('select');
        select.className = "city-traffic";
        select.dataset.city = city;
        select.innerHTML = `
            <option value="low">🟢 Low</option>
            <option value="medium">🟡 Medium</option>
            <option value="high">🔴 High</option>
        `;

        wrapper.appendChild(label);
        wrapper.appendChild(select);
        trafficContainer.appendChild(wrapper);
    });

    // Add None option for end
    const noneOption = new Option("None", "none");
    endSelect.appendChild(noneOption);

    // Map layer
    const map = L.map('map').setView([46.5, 2.5], 6);
    let routeLayers = [];

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Form submission logic
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const start = formData.get('start');
        const end = formData.get('end');
        const algorithm = formData.get('algorithm');
        const deliverymen = formData.get('numDeliverymen') || null;

        const traffic = {};
        document.querySelectorAll('.city-traffic').forEach(select => {
            const city = select.dataset.city;
            traffic[city] = select.value;
        });

        const waypoints = [];
        document.querySelectorAll('.cluster-city:checked').forEach(cb => {
            waypoints.push(cb.value);
        });

        console.log("Form Data:", { start, end, algorithm, traffic, waypoints, num_deliverymen: deliverymen }); // Debugging

        try {
            const response = await fetch('/api/clustered_routes', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ start, end, algorithm, traffic, waypoints, num_deliverymen: deliverymen })
            });

            if (!response.ok) {
                throw new Error(`API error: ${response.statusText}`);
            }

            const data = await response.json();
            console.log("API Data:", data); // Debugging

            if (data.error) {
                alert(data.error);
                return;
            }

            const resultDiv = document.getElementById("clusterResults");
            resultDiv.innerHTML = ""; // Clear previous results

            // Draw each cluster route
            data.routes.forEach((route, i) => {
                const latlngs = route.path.map(p => [p.lat, p.lon]);

                const polyline = L.polyline(latlngs, { color: 'blue', weight: 5 }).addTo(map);
                routeLayers.push(polyline);
                map.fitBounds(polyline.getBounds());

                latlngs.forEach(p => {
                    const marker = L.marker(p).addTo(map).bindPopup("📍 " + p.city);
                    routeLayers.push(marker);
                });

                const info = document.createElement("p");
                info.innerHTML = `<strong>Path n${i + 1}:</strong> ${route.path.map(p => p.city).join(" → ")}<br><em>Distance:</em> ${route.distance.toFixed(2)} km`;
                resultDiv.appendChild(info);

            });
        } catch (error) {
            console.error("Error fetching clustered routes:", error);
            alert("Failed to fetch clustered routes. Check the console for details.");
        }
    });

    // Dark mode toggle
    document.getElementById('toggleDark').addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
    });
});
