document.addEventListener('DOMContentLoaded', () => {

    const form = document.getElementById('pathForm') || document.getElementById('clusterForm');
            const map = L.map('map').setView([46.5, 2.5], 6); // Center of France
            let polyline;
            let markers = [];

            const cities = {
                'Paris': [48.8566, 2.3522],
                'Lyon': [45.7640, 4.8357],
                'Marseille': [43.2965, 5.3698],
                'Nice': [43.7102, 7.2620],
                'Nantes': [47.2184, -1.5536],
                'Bordeaux': [44.8378, -0.5792],
                'Toulouse': [43.6047, 1.4442],
                'Lille': [50.6292, 3.0573],
                'Strasbourg': [48.5734, 7.7521]
            };
            
                    // Dynamically populate dropdowns and delivery checkboxes
            const startSelect = document.getElementById('start');
            const endSelect = document.getElementById('end');
            const citiesContainer =(
                document.getElementById('waypointCheckboxes') ||
                document.getElementById('clusterDeliveryCities')
            );      

            if (startSelect && endSelect && citiesContainer) {
            Object.keys(cities).forEach(city => {
                const option1 = new Option(city, city);
                const option2 = new Option(city, city);
                startSelect.appendChild(option1);
                endSelect.appendChild(option2.cloneNode(true));

                const div = document.createElement('div');
                div.className = "cluster-checkbox";
                div.innerHTML = `
                <label>
                    <input type="checkbox" class="cluster-city" value="${city}"> ${city}
                </label>
                `;
                citiesContainer.appendChild(div);
            });
            }


            const trafficContainer = document.getElementById('cityTrafficControls');

            Object.keys(cities).forEach(city => {
                const wrapper = document.createElement('div');
                wrapper.style.flex = "0 0 calc(50% - 10px)"; // 2 per row
                wrapper.style.display = "flex";
                wrapper.style.alignItems = "center";
                wrapper.style.gap = "10px";

                const label = document.createElement('label');
                label.textContent = city;
                label.setAttribute("for", `traffic-${city}`);
                label.style.width = "80px";
                label.style.fontWeight = "bold";

                const select = document.createElement('select');
                select.id = `traffic-${city}`;
                select.className = "city-traffic";
                select.dataset.city = city;
                select.innerHTML = `
                    <option value="low">🟢 Low</option>
                    <option value="medium">🟡 Medium</option>
                    <option value="high">🔴 High</option>
                `;

                wrapper.appendChild(label);
                wrapper.appendChild(select);
                trafficContainer.appendChild(wrapper);
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);

            form.addEventListener('submit', async (e) => {
                e.preventDefault();

                const formData = new FormData(form);
                const start = formData.get('start');
                const end = formData.get('end');
                const algorithm = formData.get('algorithm');

                const traffic = {};
                document.querySelectorAll('.city-traffic').forEach(select => {
                    const city = select.dataset.city;
                    const level = select.value;
                    traffic[city] = level;
                });

                // Get delivery cities from checked checkboxes
                const waypoints = [];
                document.querySelectorAll('.waypoint-checkbox:checked, .cluster-city:checked').forEach(cb => {
                    waypoints.push(cb.value);
                });


                const response = await fetch('/api/path', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ start, end, algorithm, traffic, waypoints })
                });

                const data = await response.json();

                if (data.error) {
                    alert(data.error);
                    return;
                }

                const path = data.path;
                const distance = data.distance;

                document.getElementById('pathText').innerText = 'Path: ' + path.map(p => p.city).join(' → ');
                document.getElementById('distanceText').innerText = 'Total Distance: ' + distance + ' km';

                // Clear previous path
                if (polyline) map.removeLayer(polyline);
                markers.forEach(m => map.removeLayer(m));
                markers = [];

                const latlngs = path.map(p => [p.lat, p.lon]);

                polyline = L.polyline(latlngs, { color: 'red', weight: 5 }).addTo(map);
                map.fitBounds(polyline.getBounds());

                path.forEach(p => {
                    const marker = L.marker([p.lat, p.lon])
                        .addTo(map)
                        .bindPopup("📍 " + p.city);
                    markers.push(marker);
                });
            });

            // Dark mode toggle
            document.getElementById('toggleDark').addEventListener('click', () => {
                document.body.classList.toggle('dark-mode');
            });
});