let drawnPoints = [];
let sketchPolyline = null;
let sketchCursor = null;
let sketchLayer = null;
let cityHighlightLayer = null;

let truckIcon = L.divIcon({
    html: '<div style="font-size: 15px;">🚚</div>',
    className: '',
    iconSize: [20, 20],
    iconAnchor: [15, 15]
});

function initSketchMode(map, cities) {
	
	let sketchPoints = [];
    let drawing = false;
    
	if (sketchLayer) sketchLayer.clearLayers();
    else sketchLayer = L.layerGroup().addTo(map);

    if (!cityHighlightLayer) cityHighlightLayer = L.layerGroup().addTo(map);
    else cityHighlightLayer.clearLayers();

    if (!sketchCursor) {
        sketchCursor = L.marker([0, 0], { icon: truckIcon, interactive: false });
        sketchCursor.addTo(map);
    }

    map.getContainer().style.cursor = 'none';

    function getNearestCity(point, cities) {
        let nearest = null;
        let minDist = Infinity;
        for (const city in cities) {
            const dist = map.distance(point, cities[city]);
            if (dist < minDist && dist < 20000) {
                minDist = dist;
                nearest = { city, coords: cities[city] };
            }
        }
        return nearest;
    }

    const onMouseDown = (e) => {
        drawnPoints = [e.latlng];
        sketchLayer.clearLayers();
        cityHighlightLayer.clearLayers();

        sketchPolyline = L.polyline([e.latlng], {
            color: 'blue',
            weight: 8
        }).addTo(sketchLayer);
        drawing = true;
    };

    const onMouseMove = (e) => {
        if (sketchCursor) sketchCursor.setLatLng(e.latlng);

        if (drawing) {
            drawnPoints.push(e.latlng);
            if (sketchPolyline) {
                sketchPolyline.setLatLngs(drawnPoints);
            }

            const nearest = getNearestCity(e.latlng, cities);
            if (nearest) {
                cityHighlightLayer.clearLayers();
                L.circle(nearest.coords, {
                    radius: 10000,
                    color: 'orange',
                    fillColor: 'gold',
                    fillOpacity: 0.5,
                    weight: 2
                }).addTo(cityHighlightLayer);
            }
        }
    };

    const onMouseUp = async () => {
        drawing = false;
        map.getContainer().style.cursor = 'default';

        const response = await fetch('/api/sketch-path', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sketch: drawnPoints })
        });

        const result = await response.json();

        if (result.error) {
            alert(result.error);
            return;
        }

        const coords = result.path.map(city => {
            const info = cities[city];
            return { lat: info[0], lon: info[1] };
        });

        animateTruck(coords, map);
        drawActualPath(coords, map);
        alert(`Path: ${result.path.join(' → ')}\nScore: ${result.score}%`);
    };

    map.on('mousedown', onMouseDown);
    map.on('mousemove', onMouseMove);
    map.on('mouseup', onMouseUp);

    return { onMouseDown, onMouseMove, onMouseUp };
}

function animateTruck(pathCoords, map) {
    if (!pathCoords.length) return;

    const truck = L.marker([pathCoords[0].lat, pathCoords[0].lon], {
        icon: truckIcon
    }).addTo(map);

    let index = 0;
    let steps = 100;
    let step = 0;

    function interpolate(p1, p2, t) {
        return [
            p1.lat + (p2.lat - p1.lat) * t,
            p1.lon + (p2.lon - p1.lon) * t
        ];
    }

    function move() {
        if (index >= pathCoords.length - 1) return;

        const p1 = pathCoords[index];
        const p2 = pathCoords[index + 1];
        const [lat, lon] = interpolate(p1, p2, step / steps);
        truck.setLatLng([lat, lon]);

        step++;
        if (step > steps) {
            index++;
            step = 0;
        }

        if (index < pathCoords.length - 1) {
            setTimeout(() => requestAnimationFrame(move), 15);
        }
    }

    move();
}

function drawActualPath(coords, map) {
    const latlngs = coords.map(p => [p.lat, p.lon]);
    L.polyline(latlngs, {
        color: 'red',
        weight: 4,
        dashArray: '6, 6'
    }).addTo(map);
}
